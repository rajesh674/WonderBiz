import React ,{useEffect} from 'react';
import axios from 'axios';
import BarChart from '../Layout/utility/BarCharts';
import Btimeline from '../Layout/utility/timeline';
import {fetchPostsUsers , fetchUpcomingUsers} from '../Layout/redux/actions/ApiCall';
import { useDispatch, useSelector } from 'react-redux';
import GeoChart from '../Layout/utility/map.js';


const Home = () => {
    const postUserApi = useSelector((state) => state.reducerPosts);
    const upcomingUserApi = useSelector((state) => state.reducerUpcoming);
    const dispatch = useDispatch();

  const PostUser = async () => {
          const response= await axios.get("https://api.spacexdata.com/v3/capsules/past")
          .catch((err) =>{
              console.log('error' , err)
          })
          dispatch(fetchPostsUsers(response.data));
  }
  const UpComingUser = async () => {
    const response= await axios.get("https://api.spacexdata.com/v3/capsules/upcoming")
    .catch((err) =>{
        console.log('error' , err)
    })
   
    dispatch(fetchUpcomingUsers(response.data));
}
  useEffect(()=>{
    PostUser()
    UpComingUser()
  },[])

    const PostCount = postUserApi?.postUsers?.map((a) => {
        return a?.capsule_id
    });

    const upcomingCount = upcomingUserApi?.upcomingUsers?.map((a) => {
        return a.capsule_id
    });

    const TotalCount = [...PostCount , ...upcomingCount];



    return (<div className="col-12 col-md-10"> 
     <div className="portlet-title mb-3 pl-0 pt-0 font-size20">Analytics Dashoard </div>
     <div className="portlet mb-3">
     <div className="portlet-title mb-3">Launch Dashoard</div>
  
    <div className="d-flex justify-content-around flex-wrap">
    <div className="portlet p-3 mb-3" style={{width: '250px'}}>
    <div>{Object.keys(upcomingCount).length}</div>
    <div>Upcoming</div>
    </div>
    <div className="portlet p-3 mb-3" style={{width: '250px'}}>
    <div>{Object.keys(PostCount).length}</div>
    <div>Past</div>
    </div>
    <div className="portlet p-3 mb-3" style={{width: '250px'}}>
    <div>{Object.keys(TotalCount).length}</div>
    <div>Total</div>
    </div>
    </div>

     </div>

<div className="row mr-md-0 mb-15">
    <div className="col-12 col-md-4 pr-md-0">
        <div className="portlet mb-xs-3 mb-sm-3">
            <div className="portlet-title">Launchpad location</div>
            <div className="d-flex align-items-center" style={{width:'100%' , height: '200px'}}>
                 <GeoChart/> 
                 
                 </div>
        </div>
    </div>
    <div className="col-12 col-md-4 pr-md-0">
        <div className="portlet">
            <div className="portlet-title">Launch Over Time</div>
            <div style={{width:'100%' , height: '200px'}}><BarChart/></div>
        </div>
    </div>
    <div className="col-12 col-md-4 pr-md-0">
        <div className="portlet">
            <div className="portlet-title">Launch Timeline</div>
            <div style={{width:'100%' , height: '200px' , overflow: 'auto'}}><Btimeline/></div>
        </div>
    </div>
</div>
    </div>)
}

export default Home;