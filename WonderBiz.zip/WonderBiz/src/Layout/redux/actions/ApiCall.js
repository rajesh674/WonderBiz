//import axios from "axios";
import {
	ActionType
} from './ActionType';



export const fetchUpcomingUsers = upcoming => {
	return {
	  type: ActionType.UPCOMING_USERS_SUCCESS,
	  payload: upcoming
	}
}
  
  export const fetchPostsUsers = posts => {
	return {
	  type: ActionType.POSTS_USERS_SUCCESS,
	  payload: posts
	}
  }
  


// export const fetchUsers = () => {
// 	return function (dispatch) {
// 	  dispatch(fetchUsersRequest())
// 	  axios
// 		.get('https://jsonplaceholder.typicode.com/users')
// 		.then(response => {
// 		  // response.data is the users
// 		  const users = response.data.map(user => user.id)
// 		  dispatch(fetchUsersSuccess(users))
// 		})
// 		.catch(error => {
// 		  // error.message is the error message
// 		  dispatch(fetchUsersFailure(error.message))
// 		})
// 	}
//   }