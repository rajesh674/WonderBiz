import {
	ActionType
} from '../actions/ActionType';

const initialState = {
    postUsers:[]
  }
  const initialStateUp = {
    upcomingUsers:[]
  }

  export const reducerPosts = (state = initialState, action) => {
    switch (action.type) {
      case ActionType.POSTS_USERS_SUCCESS:
        return {
          postUsers: action.payload
        };
        default:
			return state;
    }
  }

  export const reducerUpcoming = (state = initialStateUp, action) => {
    switch (action.type) {
      case ActionType.UPCOMING_USERS_SUCCESS:
        return {
          upcomingUsers: action.payload
        };
        default:
			return state;
    }
  }