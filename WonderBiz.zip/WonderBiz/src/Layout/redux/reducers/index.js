import { combineReducers } from "redux";
import {reducerPosts , reducerUpcoming} from './ApiCall.js'

const rootReducer = combineReducers({
	reducerPosts,
	reducerUpcoming
});

export default rootReducer;
