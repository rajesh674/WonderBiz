import React from 'react';
import Timeline from '@material-ui/lab/Timeline';
import TimelineItem from '@material-ui/lab/TimelineItem';
import TimelineSeparator from '@material-ui/lab/TimelineSeparator';
import TimelineConnector from '@material-ui/lab/TimelineConnector';
import TimelineContent from '@material-ui/lab/TimelineContent';
import TimelineDot from '@material-ui/lab/TimelineDot';
import CustomizedProgressBars from '../components/CustomizedProgressBars';

export default function Btimeline() {
  return (
    <Timeline alignLeft>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot variant="outlined" color='primary' />
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent><CustomizedProgressBars/></TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot variant="outlined" color='secondary' />
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent><CustomizedProgressBars/></TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot variant="outlined" color='secondary' />
        </TimelineSeparator>
        <TimelineContent><CustomizedProgressBars/></TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot variant="outlined" color='primary' />
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent><CustomizedProgressBars/></TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot variant="outlined" color='secondary' />
          <TimelineConnector />
        </TimelineSeparator>
        <TimelineContent><CustomizedProgressBars/></TimelineContent>
      </TimelineItem>
      <TimelineItem>
        <TimelineSeparator>
          <TimelineDot variant="outlined" color='secondary' />
        </TimelineSeparator>
        <TimelineContent><CustomizedProgressBars/></TimelineContent>
      </TimelineItem>
     
    </Timeline>
  );
}