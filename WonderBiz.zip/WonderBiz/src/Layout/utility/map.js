import React from 'react';
import map from '../../assets/map.png';

const GeoChart = () => {

	// const defaultProps = {
	// 	center: {
	// 	  lat: 10.99835602,
	// 	  lng: 77.01502627
	// 	},
	// 	zoom: 11
	//   };



	return (
         <img src={map} alt="Location Map" className="w-100" />
	);
};

export default GeoChart;